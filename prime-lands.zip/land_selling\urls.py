from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.sitemaps.views import sitemap
from django.views.static import serve
from apps.views import serve_land_image
from apps.website.sitemaps import StaticViewSitemap, PlotSitemap, ProjectSitemap

sitemaps = {
    'static': StaticViewSitemap,
    'plots': PlotSitemap,
    'projects': ProjectSitemap,
}

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('apps.website.urls')),
    path('accounts/', include('apps.accounts.urls')),
    path('projects/', include('apps.projects.urls')),
    path('plots/', include('apps.plots.urls')),
    path('customers/', include('apps.customers.urls')),
    path('sales/', include('apps.sales.urls')),
    path('payments/', include('apps.payments.urls')),
    path('documents/', include('apps.documents.urls')),
    path('notifications/', include('apps.notifications.urls')),
    path('reports/', include('apps.reports.urls')),
    path('dashboard/', include('apps.dashboard.urls')),
    path('settings/', include('apps.settings.urls')),
    path('subscriptions/', include('apps.subscriptions.urls')),
    # Serve land images from landImage directory
    path('landImage/<str:filename>', serve_land_image, name='serve_land_image'),
    # SEO - Sitemap
    path('sitemap.xml', sitemap, {'sitemaps': sitemaps}, name='sitemap'),
]

# Serve media files in production (DEBUG=False)
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
else:
    urlpatterns += [
        re_path(r'^media/(?P<path>.*)$', serve, {'document_root': settings.MEDIA_ROOT}),
    ]
